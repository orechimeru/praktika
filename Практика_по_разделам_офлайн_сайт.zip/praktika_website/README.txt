CÁCH MỞ WEBSITE:
1. Giải nén file ZIP.
2. Mở file index.html bằng Chrome/Edge/Firefox/Safari.
3. Không cần internet hoặc VPN.

Website chứa đủ 56 trang dưới dạng văn bản tìm kiếm được và PDF gốc không chỉnh sửa.
